import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useNavigate, useLocation } from 'react-router-dom';

const API_URL = 'http://localhost:5000/students';

const Form = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const searchParams = new URLSearchParams(location.search);
  const editMode = searchParams.get('edit') === 'true';
  const studentId = searchParams.get('id');

  const [formData, setFormData] = useState({
    id: '', firstName: '', middleName: '', lastName: '', presentAddress: '',
    provincialAddress: '', lengthStay: '', sex: '', cStatus: '', dob: '',
    age: '', pob: '', hea: '', religion: '', cNumber: '', email: ''
  });

  const [loading, setLoading] = useState(false); 

  useEffect(() => {
    if (editMode && studentId) {
      fetchStudentData(studentId);
    }
  }, [editMode, studentId]);

  const fetchStudentData = async (id) => {
    try {
      const token = localStorage.getItem('token');
      setLoading(true);
  
      const response = await axios.get(`${API_URL}/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
  
      setTimeout(() => {
        setFormData(response.data);
        setLoading(false);
      }, 600);
    } catch (error) {
      toast.error('Error fetching student data');
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
  
    try {
      const token = localStorage.getItem('token');
      const config = { headers: { Authorization: `Bearer ${token}` } };
  
      if (editMode) {
        await axios.put(`${API_URL}/${studentId}`, formData, config);
        toast.success('Student updated successfully!');
      } else {
        await axios.post(API_URL, formData, config);
        toast.success('Student added successfully!');
      }
  
      setTimeout(() => {
        setLoading(false);
        navigate('/masterlist');
      }, 500);
    } catch (error) {
      toast.error('Error saving resident data');
      setLoading(false);
    }
  };

  return (
    <div className="containert">
    <div className="container mt-4">
      <h2 className="text-center">{editMode ? 'Edit Resident' : 'Add Resident'}</h2>
      {loading && <div className="text-center"><div className="spinner-border text-success" role="status"></div></div>}
      <form className="row g-3" onSubmit={handleSubmit}>
        
        <div className="col-md-2">
          <label className="form-label">ID</label>
          <input type="text" className="form-control" name="id" value={formData.id} onChange={handleChange} required disabled={editMode} />
        </div>

        <div className="col-md-5">
          <label className="form-label">First Name</label>
          <input type="text" className="form-control" name="firstName" value={formData.firstName} onChange={handleChange} required />
        </div>
        
        <div className="col-md-5">
          <label className="form-label">Middle Name</label>
          <input type="text" className="form-control" name="middleName" value={formData.middleName} onChange={handleChange} />
        </div>
        
        <div className="col-md-5">
          <label className="form-label">Last Name</label>
          <input type="text" className="form-control" name="lastName" value={formData.lastName} onChange={handleChange} required />
        </div>

        <div className="col-md-6">
          <label className="form-label">Present Address</label>
          <input type="text" className="form-control" name="presentAddress" value={formData.presentAddress} onChange={handleChange} required />
        </div>
        
        <div className="col-md-6">
          <label className="form-label">Provincial Address</label>
          <input type="text" className="form-control" name="provincialAddress" value={formData.provincialAddress} onChange={handleChange} />
        </div>

        <div className="col-md-2">
          <label className="form-label">Length of Stay (year/s)</label>
          <input type="number" className="form-control" name="lengthStay" value={formData.lengthStay} onChange={handleChange} required />
        </div>

        <div className="col-md-4">
          <label className="form-label">Gender</label>
          <select className="form-select" name="sex" value={formData.sex} onChange={handleChange} required>
            <option value="">Select...</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Others">Others</option>
            <option value="Prefer not to say">Prefer not to say</option>
          </select>
        </div>

        <div className="col-md-4">
          <label className="form-label">Civil Status</label>
          <select className="form-select" name="cStatus" value={formData.cStatus} onChange={handleChange} required>
            <option value="">Choose...</option>
            <option value="Single">Single</option>
            <option value="Married">Married</option>
            <option value="Widowed">Widowed</option>
            <option value="Divorced">Divorced</option>
          </select>
        </div>

        <div className="col-md-4">
          <label className="form-label">Date of Birth</label>
          <input type="date" className="form-control" name="dob" value={formData.dob} onChange={handleChange} required />
        </div>

        <div className="col-md-4">
          <label className="form-label">Age</label>
          <input type="number" className="form-control" name="age" value={formData.age} onChange={handleChange} required />
        </div>

        <div className="col-md-6">
          <label className="form-label">Place of Birth</label>
          <input type="text" className="form-control" name="pob" value={formData.pob} onChange={handleChange} required />
        </div>

        <div className="col-md-4">
          <label className="form-label">Highest Educational Attainment</label>
          <select className="form-select" name="hea" value={formData.hea} onChange={handleChange} required>
            <option value="">Choose...</option>
            <option value="No Grade Completed">No Grade Completed</option>
            <option value="Elementary Graduate">Elementary Graduate</option>
            <option value="Highschool Graduate">Highschool Graduate</option>
            <option value="Technical Vocational Graduate">Technical Vocational Graduate</option>
            <option value="College Graduate">College Graduate</option>
            <option value="Masters Graduate">Masters Graduate</option>
            <option value="Doctorate Graduate">Doctorate Graduate</option>
          </select>
        </div>

        <div className="col-md-4">
          <label className="form-label">Religion</label>
          <input type="text" className="form-control" name="religion" value={formData.religion} onChange={handleChange} required />
        </div>

        <div className="col-md-3">
          <label className="form-label">Contact Number</label>
          <input type="text" className="form-control" name="cNumber" value={formData.cNumber} onChange={handleChange} required />
        </div>

        <div className="col-md-5">
          <label className="form-label">Email</label>
          <input type="email" className="form-control" name="email" value={formData.email} onChange={handleChange} required />
        </div>

        <div className="col-12">
          <button className="btn btn-success" type="submit">{editMode ? 'Update Student' : 'Add Student'}</button>
        </div>
      </form>
    </div>
    </div>
  );
};

export default Form;
