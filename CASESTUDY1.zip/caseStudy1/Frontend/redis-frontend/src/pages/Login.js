import React, { useState, useContext } from 'react';
import { motion } from 'framer-motion'; // ✅ Animation Library
import AuthContext from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const { login } = useContext(AuthContext);
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [loginSuccess, setLoginSuccess] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const result = await login(credentials.username, credentials.password);

    setTimeout(() => {
      setLoading(false);
      if (result.success) {
        setLoginSuccess(true);
        setTimeout(() => navigate('/dashboard'), 1000); // ✅ Delay navigation after success animation
      } else {
        setError(result.message);
      }
    }); // ✅ Increase spinner duration
  };

  return (
    <div className="login-page">
      {/* Animated Background */}
      <motion.div
        className="animated-bg"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
      ></motion.div>

      {/* Full-Screen Loading Overlay */}
      {loading && (
        <div className="loading-overlay">
          <motion.div
            className="spinner-container"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1, scale: [1, 1.2, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <div className="spinner-border text-light" role="status"></div>
            <p className="loading-text">Authenticating...</p>
          </motion.div>
        </div>
      )}

      {/* Login Form */}
      <motion.div
        className="login-container"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, type: 'spring', stiffness: 120 }}
      >
        <div className="login-card">
          <h2 className="login-title">Welcome Back</h2>
          <p className="login-subtitle">Sign in to continue</p>

          {error && <div className="alert alert-danger">{error}</div>}

          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <input
                type="text"
                name="username"
                className="form-control"
                placeholder="Username"
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <input
                type="password"
                name="password"
                className="form-control"
                placeholder="Password"
                onChange={handleChange}
                required
              />
            </div>

            <button type="submit" className="btn login-btn" disabled={loading}>
              {loading ? (
                <>
                  <motion.span
                    className="spinner-border spinner-border-sm"
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 1 }}
                  ></motion.span>
                  Logging in...
                </>
              ) : (
                'Login'
              )}
            </button>
          </form>

          {/* Success Animation */}
          {loginSuccess && (
            <motion.div
              className="login-success"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1, scale: [0.8, 1.2, 1] }}
              transition={{ duration: 1 }}
            >
              ✅ Login Successful! Redirecting...
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default Login;
