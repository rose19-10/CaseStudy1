import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import AuthContext from '../context/AuthContext';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ActivityLogs = () => {
  const { user } = useContext(AuthContext);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const logsPerPage = 12; // ✅ Show 12 logs per page

  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/auth/logs', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLogs(response.data);
      setLoading(false);
    } catch (error) {
      toast.error('Error fetching logs');
      setLoading(false);
    }
  };

  if (!user || user.role !== 'admin') {
    return <h2 className="text-center text-danger">🚫 Access Denied</h2>;
  }

  // ✅ Pagination Logic
  const indexOfLastLog = currentPage * logsPerPage;
  const indexOfFirstLog = indexOfLastLog - logsPerPage;
  const currentLogs = logs.slice(indexOfFirstLog, indexOfLastLog);

  // ✅ Change page functions
  const nextPage = () => setCurrentPage(currentPage + 1);
  const prevPage = () => setCurrentPage(currentPage - 1);

  return (
    <div className="container mt-5">
      <h2 className="text-center">User Logs</h2>

      {/* ✅ Show loading spinner */}
      {loading && (
        <div className="text-center my-3">
          <div className="spinner-border text-primary" role="status"></div>
        </div>
      )}

      <div className="table-responsive">
        <table className="table table-striped table-hover log-table">
          <thead className="table-light">
            <tr>
              <th>Action</th>
              <th>Target</th> {/* ✅ Changed 'Username' to 'Target' */}
              <th>Performed By</th>
              <th>Timestamp</th>
            </tr>
          </thead>
          <tbody>
  {currentLogs.length === 0 ? (
    <tr>
      <td colSpan="4" className="text-center">No logs found.</td>
    </tr>
  ) : (
    currentLogs.map((log, index) => (
      <tr key={index}>
        <td>
          <span className={`badge ${log.action.includes('deleted') ? 'bg-danger' : 'bg-success'}`}>
            {log.action}
          </span>
        </td>
        <td>
          {/* ✅ Ensure correct target is displayed */}
          {log.targetUser 
            ? log.targetUser  // Shows the username of the updated/deleted user
            : log.studentId 
            ? `Student ${log.studentId}`  // Shows the student ID if action involves residents
            : 'N/A'}
        </td>
        <td>{log.performedBy}</td>
        <td>{new Date(log.timestamp).toLocaleString()}</td>
      </tr>
    ))
  )}
</tbody>

        </table>
      </div>

      {/* ✅ Pagination Buttons */}
      <div className="pagination-buttons d-flex justify-content-center mt-10">
        <button className="btn btn-secondary me-1" onClick={prevPage} disabled={currentPage === 1}>
          ← Previous
        </button>
        <span className="align-self-center">Page {currentPage}</span>
        <button className="btn btn-secondary ms-1" onClick={nextPage} disabled={indexOfLastLog >= logs.length}>
          Next →
        </button>
      </div>
    </div>
  );
};

export default ActivityLogs;
