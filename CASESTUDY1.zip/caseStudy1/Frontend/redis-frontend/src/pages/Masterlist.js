import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import AuthContext from '../context/AuthContext';
import * as XLSX from 'xlsx';

const API_URL = 'http://localhost:5000/students';

const Masterlist = () => {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const studentsPerPage = 10;

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(API_URL, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setStudents(response.data);
    } catch (error) {
      toast.error('Error fetching students');
    }
  };

  // 📂 **Export to CSV**
  const exportToCSV = () => {
    const csvHeaders = [
      'ID,First Name,Middle Name,Last Name,Present Address,Provincial Address,Years Stayed,Sex,Civil Status,DOB,Age,Place of Birth,Highest Educational Attainment,Religion,Contact,Email'
    ];

    const csvRows = students.map(student =>
      [
        student.id, 
        student.firstName, 
        student.middleName, 
        student.lastName,
        student.presentAddress, 
        student.provincialAddress, 
        student.lengthStay,
        student.sex, 
        student.cStatus, 
        student.dob, 
        student.age, 
        student.pob, 
        student.hea, 
        student.religion, 
        student.cNumber, 
        student.email
      ].join(',')
    );

    const csvContent = [csvHeaders, ...csvRows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'masterlist.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this student?')) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${API_URL}/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Student deleted successfully');
      fetchStudents();
    } catch (error) {
      toast.error('Unauthorized access. Only admins can delete a profile.');
    }
  };

  // 🔍 **Search Functionality**
  const filteredStudents = students.filter((student) =>
    `${student.firstName} ${student.lastName} ${student.presentAddress} ${student.provincialAddress} ${student.sex} ${student.cStatus} ${student.age} ${student.pob} ${student.hea} ${student.religion}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  // 📌 **Sorting Functionality**
  const sortedStudents = [...filteredStudents].sort((a, b) => {
    if (sortBy === 'id-desc') return b.id - a.id;
    if (sortBy === 'id-asc') return a.id - b.id;
    if (sortBy === 'name-asc') return a.firstName.localeCompare(b.firstName);
    if (sortBy === 'name-desc') return b.firstName.localeCompare(a.firstName);
    if (sortBy === 'age-asc') return a.age - b.age;
    if (sortBy === 'age-desc') return b.age - a.age;
    if (sortBy === 'lengthStay-asc') return a.lengthStay - b.lengthStay;
    if (sortBy === 'lengthStay-desc') return b.lengthStay - a.lengthStay;
    if (sortBy === 'cStatus') return a.cStatus.localeCompare(b.cStatus);
    return 0;
  });

  // 📊 **Pagination**
  const indexOfLastStudent = currentPage * studentsPerPage;
  const indexOfFirstStudent = indexOfLastStudent - studentsPerPage;
  const currentStudents = sortedStudents.slice(indexOfFirstStudent, indexOfLastStudent);

  const nextPage = () => setCurrentPage(currentPage + 1);
  const prevPage = () => setCurrentPage(currentPage - 1);

  // 📂 **Export to Excel**
  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(students);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Masterlist');
    XLSX.writeFile(workbook, 'masterlist.xlsx');
  };

  

  return (
    <div className="container mt-5">
      <h2 className="text-center">Resident Profile</h2>
      <input
          type="text"
          className="form-control search-bar"
          placeholder="Search by name, age.."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      <div className="d-flex justify-content-between align-items-center my-4">
        
        <select className="form-select sort-dropdown" onChange={(e) => setSortBy(e.target.value)}>
          <option value="">Sort By</option>
          <option value="name-asc">Name</option>
          <option value="age-asc">Age</option>
          <option value="cStatus">Civil Status</option>
        </select>
        
        <button className="btn btn-success" onClick={exportToExcel}>Export to Excel</button>
        <button className="btn btn-warning" onClick={exportToCSV}>Export to CSV</button>
      </div>

      <div className="table-responsive">
        <table className="table table-striped table-hover masterlist-table">
          <thead className="table-light">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Sex</th>
              <th>Age</th>
              <th>Date of Birth</th>
              <th>Place of Birth</th>
              <th>Present Address</th>
              <th>Permanent Address</th>
              <th>Civil Status</th>
              <th>Years of Residency</th>
              <th>Educational Attainment</th>
              <th>Religion</th>
              <th>Contact</th>
              <th>Email</th>
              {user.role === 'admin' && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {currentStudents.map((student) => (
              <tr key={student.id}>
                <td>{student.id}</td>
                <td>{`${student.firstName} ${student.middleName} ${student.lastName}`}</td>
                <td>{student.presentAddress}</td>
                <td>{student.provincialAddress}</td>
                <td>{student.lengthStay}</td>
                <td>{student.sex}</td>
                <td>{student.cStatus}</td>
                <td>{student.dob}</td>
                <td>{student.age}</td>
                <td>{student.pob}</td>
                <td>{student.hea}</td>
                <td>{student.religion}</td>
                <td>{student.cNumber}</td>
                <td>{student.email}</td>
                {user.role === 'admin' && (
                  <td>
                    <button className="btn btn-primary btn-sm me-2" onClick={() => navigate(`/form?edit=true&id=${student.id}`)}>Edit</button>
                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(student.id)}>Delete</button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="pagination-buttons">
        <button className="btn btn-secondary" onClick={prevPage} disabled={currentPage === 1}>← Previous</button>
        <span> Page {currentPage} </span>
        <button className="btn btn-secondary" onClick={nextPage} disabled={indexOfLastStudent >= filteredStudents.length}>Next →</button>
      </div>
    </div>
  );
};

export default Masterlist;
