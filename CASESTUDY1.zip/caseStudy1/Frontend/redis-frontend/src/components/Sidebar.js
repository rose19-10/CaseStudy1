import React, { useContext, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion'; // ✅ Page Transition Animations
import AuthContext from '../context/AuthContext';
import './Sidebar.css'; // ✅ Import styles

const Sidebar = ({ isCollapsed, toggleSidebar }) => {
  const { user, logout } = useContext(AuthContext);
  const isAdmin = user?.role === 'admin';
  const auth = useContext(AuthContext);
  const navigate = useNavigate();

  // State for logout spinner
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  // ✅ Logout with spinner & redirect
  const handleLogout = () => {
    setIsLoggingOut(true);
    setTimeout(() => {
      logout();
      setIsLoggingOut(false);
      navigate('/login');
    }, 2000);
  };

  return (
    <motion.div
      className={`sidebar ${isCollapsed ? 'collapsed' : ''}`}
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      onClick={toggleSidebar}
    >
      <h4 className="text-center">
        {isCollapsed ? <i className="bi bi-list"></i> : (
          <>
            <span className='user'>User, </span>
            <span className="username">{auth.user?.username || 'Guest'}</span>
          </>
        )}
      </h4>

      <hr />

      <ul className="nav nav-pills flex-column mb-auto" onClick={(e) => e.stopPropagation()}>
  {!user ? (
    <>
      <li>
        <NavLink
          to="/"
          className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
        >
          <i className="bi bi-house"></i> Home
        </NavLink>
      </li>
      <li>
        <NavLink
          to="/login"
          className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
        >
          <i className="bi bi-box-arrow-in-right"></i> Login
        </NavLink>
      </li>
      <li>
        <NavLink
          to="/register"
          className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
        >
          <i className="bi bi-person-plus"></i> Register
        </NavLink>
      </li>
    </>
  ) : (
    <>
      <li>
        <NavLink
          to="/dashboard"
          className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
        >
          <i className="bi bi-speedometer"></i> Home
        </NavLink>
      </li>
      <li>
        <NavLink
          to="/masterlist"
          className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
        >
          <i className="bi bi-card-checklist"></i> Resident Profile
        </NavLink>
      </li>
      {isAdmin && (
        <li>
          <NavLink
            to="/form"
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
          >
            <i className="bi bi-ui-checks"></i> Form
          </NavLink>
        </li>
      )}
      {isAdmin && (
        <li>
          <NavLink
            to="/manage-users"
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
          >
            <i className="bi bi-person-lock"></i> Active Users
          </NavLink>
        </li>
      )}
      {isAdmin && (
        <li>
          <NavLink
            to="/logs"
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
          >
            <i className="bi bi-list-columns"></i> User Logs
          </NavLink>
        </li>
      )}
      <li>
        <NavLink
          to="/profile"
          className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
        >
          <i className="bi bi-person-circle"></i> Settings
        </NavLink>
      </li>
    </>
  )}
</ul>


      <hr />

      {!isCollapsed && user && (
        <div className="text-center" onClick={(e) => e.stopPropagation()}>
          <button className="btn btn-danger logout-btn" onClick={handleLogout} disabled={isLoggingOut}>
            {isLoggingOut ? (
              <>
                <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                Logging out...
              </>
            ) : (
              <>
                <i className="bi bi-box-arrow-left"></i> Logout
              </>
            )}
          </button>
        </div>
      )}
    </motion.div>
  );
};

export default Sidebar;
